package com.ngsempire.sift;

import org.bukkit.Material;
import org.bukkit.block.Biome;
import org.bukkit.generator.BiomeProvider;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;

import java.util.List;
import java.util.Random;

/** Deterministic, seed-based terrain generator. Uses existing vanilla biomes/materials. */
public final class SiftChunkGenerator extends ChunkGenerator {
    private final NGSSiftPlugin plugin;
    public SiftChunkGenerator(NGSSiftPlugin plugin) { this.plugin = plugin; }

    @Override public BiomeProvider getDefaultBiomeProvider(WorldInfo worldInfo) {
        return new BiomeProvider() {
            @Override public Biome getBiome(WorldInfo info, int x, int y, int z) {
                int v = Math.floorMod((x / 96) + (z / 96), 5);
                return switch (v) {
                    case 0 -> Biome.PALE_GARDEN;
                    case 1 -> Biome.MEADOW;
                    case 2 -> Biome.DEEP_DARK;
                    case 3 -> Biome.DRIPSTONE_CAVES;
                    default -> Biome.WINDSWEPT_GRAVELLY_HILLS;
                };
            }
            @Override public List<Biome> getBiomes(WorldInfo info) {
                return List.of(Biome.PALE_GARDEN, Biome.MEADOW, Biome.DEEP_DARK, Biome.DRIPSTONE_CAVES, Biome.WINDSWEPT_GRAVELLY_HILLS);
            }
        };
    }

    @Override public void generateNoise(WorldInfo worldInfo, Random random, int chunkX, int chunkZ, ChunkData data) {
        int min = Math.max(data.getMinHeight(), plugin.getConfig().getInt("generation.min-y", -64));
        int max = Math.min(data.getMaxHeight(), plugin.getConfig().getInt("generation.max-y", 192));
        double base = plugin.getConfig().getDouble("generation.base-height", 72);
        double amp = plugin.getConfig().getDouble("generation.height-amplitude", 26);
        double scale = plugin.getConfig().getDouble("generation.plateau-scale", 0.035);
        double caveThreshold = plugin.getConfig().getDouble("generation.cave-threshold", .56);
        long seed = worldInfo.getSeed();
        for (int lx=0; lx<16; lx++) for (int lz=0; lz<16; lz++) {
            int x=chunkX*16+lx, z=chunkZ*16+lz;
            double a = Math.sin(x*scale) * Math.cos(z*scale*.83);
            double b = Math.sin((x+z)*scale*.47) * Math.cos((x-z)*scale*.31);
            double ridge = 1.0 - Math.abs(Math.sin(x*scale*.42) * Math.cos(z*scale*.42));
            int surface = (int)Math.max(min+12, Math.min(max-12, base + amp*(a*.52+b*.27+ridge*.45)));
            for (int y=min; y<=surface; y++) {
                Material m;
                if (y == min) m=Material.BEDROCK;
                else if (y < min+5) m=Material.DEEPSLATE;
                else if (y < surface-5) m = y < 0 ? Material.DEEPSLATE : Material.STONE;
                else if (y < surface-1) m = ((x*31L+z*17L+y*13L+seed)&7)==0 ? Material.MOSS_BLOCK : Material.TUFF;
                else m = (Math.floorMod(x*7+z*11, 13)==0) ? Material.MOSS_BLOCK : (Math.floorMod(x+z, 7)==0 ? Material.PODZOL : Material.GRASS_BLOCK);
                // A coherent 3D field creates caves and occasional vertical fissures.
                double cave = Math.sin(x*.105 + y*.081) * Math.cos(z*.097-y*.067) * Math.sin((x+z+y)*.043);
                boolean deepCave = y < surface-7 && y > min+5 && cave > caveThreshold;
                boolean ravine = Math.abs(Math.sin((x+z*.35)*.035)) < .018 && y < surface-4;
                data.setBlock(lx,y,lz,(deepCave || ravine) ? Material.AIR : m);
            }
            // Small crystal seams underground, deterministic and sparse.
            long h = mix(seed ^ ((long)x*341873128712L) ^ ((long)z*132897987541L));
            if (Math.floorMod(h, 1000) < (int)(plugin.getConfig().getDouble("generation.crystal-chance", .035)*1000)) {
                int cy = min + 10 + (int)Math.floorMod(h >>> 12, Math.max(1, surface-min-15));
                if (cy < max-2) data.setBlock(lx, cy, lz, Material.AMETHYST_BLOCK);
            }
        }
        // One deterministic ruin candidate per chunk; bounded to avoid generating in every chunk.
        double chance = plugin.getConfig().getDouble("generation.ruins-chance", .12);
        long r = mix(seed ^ ((long)chunkX*0x9E3779B97F4A7C15L) ^ ((long)chunkZ*0xC2B2AE3D27D4EB4FL));
        if (plugin.getConfig().getBoolean("structures.enabled", true) && Math.floorMod(r, 10000) < chance*10000) {
            int cx=5+(int)Math.floorMod(r>>>8,6), cz=5+(int)Math.floorMod(r>>>16,6);
            int y=plugin.getConfig().getInt("generation.base-height",72);
            for(int dx=-3;dx<=3;dx++) for(int dz=-3;dz<=3;dz++) {
                if(Math.abs(dx)==3 || Math.abs(dz)==3) data.setBlock(cx+dx,y,cz+dz,Material.DEEPSLATE_BRICKS);
                if(Math.abs(dx)==3 || Math.abs(dz)==3) data.setBlock(cx+dx,y+1,cz+dz,Material.CRACKED_DEEPSLATE_BRICKS);
            }
            data.setBlock(cx,y,cz,Material.SCULK_CATALYST);
            data.setBlock(cx,y+1,cz,Material.CRYING_OBSIDIAN);
            data.setBlock(cx+1,y,cz,Material.AMETHYST_BLOCK);
            data.setBlock(cx-1,y,cz,Material.AMETHYST_BLOCK);
        }
    }
    private static long mix(long z) { z=(z^(z>>>30))*0xbf58476d1ce4e5b9L; z=(z^(z>>>27))*0x94d049bb133111ebL; return z^(z>>>31); }
}
