package com.ngsempire.sift;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.command.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

public final class NGSSiftPlugin extends JavaPlugin implements Listener, TabCompleter, CommandExecutor {
    private NamespacedKey itemKey;
    private final Map<UUID, Long> portalCooldown = new HashMap<>();
    private final Map<UUID, Long> abilityCooldown = new HashMap<>();
    private final Map<UUID, Location> pendingReturn = new HashMap<>();
    private final Set<UUID> teleporting = new HashSet<>();
    private World siftWorld;

    @Override public void onEnable() {
        saveDefaultConfig(); itemKey = new NamespacedKey(this, "sift_item");
        Objects.requireNonNull(getCommand("sift")).setExecutor(this);
        Objects.requireNonNull(getCommand("sift")).setTabCompleter(this);
        getServer().getPluginManager().registerEvents(this, this);
        loadReturnLocations();
        if (getConfig().getBoolean("world.auto-create", true)) createSiftWorld();
        if (getConfig().getBoolean("recipes.enabled", true)) registerRecipes();
        getLogger().info("NGSSift enabled. Dimension available: " + (siftWorld != null));
    }

    @Override public void onDisable() { saveReturnLocations(); portalCooldown.clear(); abilityCooldown.clear(); teleporting.clear(); }

    private void createSiftWorld() {
        String name=getConfig().getString("world.name","sift");
        World existing=Bukkit.getWorld(name);
        if(existing!=null){ siftWorld=existing; return; }
        WorldCreator creator=new WorldCreator(name).environment(World.Environment.NORMAL).generator(new SiftChunkGenerator(this));
        long seed=getConfig().getLong("world.seed",0); if(seed!=0) creator.seed(seed);
        try { siftWorld=creator.createWorld(); if(siftWorld!=null) { siftWorld.setGameRule(GameRule.DO_MOB_SPAWNING,true); ensureSpawn(); } }
        catch(Exception ex){ getLogger().severe("Could not create Sift world: "+ex.getMessage()); ex.printStackTrace(); }
    }
    private void ensureSpawn(){ if(siftWorld==null)return; int x=getConfig().getInt("world.spawn.x",0), z=getConfig().getInt("world.spawn.z",0); int y=getConfig().getInt("world.spawn.y",100); Location l=findSafe(siftWorld,new Location(siftWorld,x,y,z),12); if(l!=null)siftWorld.setSpawnLocation(l); }
    private Location findSafe(World w, Location target, int radius) {
        if(w==null)return null; int x=target.getBlockX(), z=target.getBlockZ();
        int min=w.getMinHeight()+2, max=w.getMaxHeight()-3;
        for(int r=0;r<=radius;r++) for(int dx=-r;dx<=r;dx++) for(int dz=-r;dz<=r;dz++) {
            if(r>0 && Math.abs(dx)!=r && Math.abs(dz)!=r)continue;
            int xx=x+dx, zz=z+dz; int yy=w.getHighestBlockYAt(xx,zz)+1; yy=Math.max(min,Math.min(max,yy));
            Location l=new Location(w,xx+.5,yy,zz+.5);
            if(l.getBlock().isPassable() && l.clone().add(0,1,0).getBlock().isPassable() && l.clone().subtract(0,1,0).getBlock().getType().isSolid())return l;
        }
        return null;
    }
    private void enter(Player p) {
        if(!p.hasPermission("ngssift.use")){msg(p,"no-permission");return;} if(siftWorld==null){createSiftWorld();}
        if(siftWorld==null){p.sendMessage(prefix()+ChatColor.RED+"The Sift world is unavailable. Check console.");return;}
        if(!p.getWorld().equals(siftWorld)) { pendingReturn.put(p.getUniqueId(),p.getLocation().clone()); saveReturnLocations(); }
        Location safe=findSafe(siftWorld,siftWorld.getSpawnLocation(),20); if(safe==null)safe=siftWorld.getSpawnLocation(); safe.getChunk().load();
        teleporting.add(p.getUniqueId()); p.teleportAsync(safe).thenAccept(ok -> Bukkit.getScheduler().runTask(this,()->{teleporting.remove(p.getUniqueId()); if(ok)msg(p,"entered");}));
    }
    private void returnPlayer(Player p) {
        Location target=pendingReturn.get(p.getUniqueId());
        if(target==null || target.getWorld()==null || target.getWorld().equals(siftWorld)) target=Bukkit.getWorlds().get(0).getSpawnLocation();
        Location safe=findSafe(target.getWorld(),target,8); if(safe==null)safe=target.getWorld().getSpawnLocation();
        Location finalSafe=safe; teleporting.add(p.getUniqueId()); p.teleportAsync(finalSafe).thenAccept(ok -> Bukkit.getScheduler().runTask(this,()->{teleporting.remove(p.getUniqueId()); if(ok){pendingReturn.remove(p.getUniqueId());saveReturnLocations();msg(p,"returned");}}));
    }
    private void loadReturnLocations(){
        if(!getConfig().isConfigurationSection("returns"))return;
        for(String id:getConfig().getConfigurationSection("returns").getKeys(false)) try { UUID u=UUID.fromString(id); String world=getConfig().getString("returns."+id+".world"); World w=Bukkit.getWorld(world); if(w!=null) pendingReturn.put(u,new Location(w,getConfig().getDouble("returns."+id+".x"),getConfig().getDouble("returns."+id+".y"),getConfig().getDouble("returns."+id+".z"), (float)getConfig().getDouble("returns."+id+".yaw"),(float)getConfig().getDouble("returns."+id+".pitch"))); }catch(Exception ignored){}
    }
    private void saveReturnLocations(){ for(var e:pendingReturn.entrySet()){ Location l=e.getValue(); if(l.getWorld()==null)continue; String p="returns."+e.getKey()+"."; getConfig().set(p+"world",l.getWorld().getName());getConfig().set(p+"x",l.getX());getConfig().set(p+"y",l.getY());getConfig().set(p+"z",l.getZ());getConfig().set(p+"yaw",l.getYaw());getConfig().set(p+"pitch",l.getPitch());} saveConfig(); }

    public ItemStack makeItem(String id) {
        Material mat; String name; List<String> lore=new ArrayList<>();
        switch(id.toLowerCase(Locale.ROOT)) {
            case "sift_igniter", "igniter" -> {mat=Material.FLINT_AND_STEEL;name="§dSift Igniter";lore.add("§7A key to the rift between worlds.");lore.add("§eRight-click the Sift portal catalyst.");}
            case "riftblade" -> {mat=Material.NETHERITE_SWORD;name="§5Riftblade";lore.add("§7A blade humming with fractured space.");lore.add("§dRight-click: Rift pulse (cooldown).");}
            case "sift_pickaxe", "pickaxe" -> {mat=Material.DIAMOND_PICKAXE;name="§bSift Pickaxe";lore.add("§7A tool attuned to strange stone.");lore.add("§dRight-click: brief Haste.");}
            case "echo_lantern", "lantern" -> {mat=Material.SOUL_LANTERN;name="§3Echo Lantern";lore.add("§7A captured glimmer from the deep rift.");}
            case "sift_crystal", "crystal" -> {mat=Material.AMETHYST_SHARD;name="§dSift Crystal";lore.add("§7A rare crystalline fragment from The Sift.");}
            case "ancient_core", "core" -> {mat=Material.HEART_OF_THE_SEA;name="§6Ancient Core";lore.add("§7The dormant heart of a forgotten shrine.");}
            case "sift_key", "key" -> {mat=Material.TRIPWIRE_HOOK;name="§eSift Key";lore.add("§7A key for ancient Sift caches.");}
            case "siftwarden_helmet", "helmet" -> {mat=Material.NETHERITE_HELMET;name="§5Siftwarden Helmet";lore.add("§7Part of the Siftwarden set.");}
            case "siftwarden_chestplate", "chestplate" -> {mat=Material.NETHERITE_CHESTPLATE;name="§5Siftwarden Chestplate";lore.add("§7Part of the Siftwarden set.");}
            case "siftwarden_leggings", "leggings" -> {mat=Material.NETHERITE_LEGGINGS;name="§5Siftwarden Leggings";lore.add("§7Part of the Siftwarden set.");}
            case "siftwarden_boots", "boots" -> {mat=Material.NETHERITE_BOOTS;name="§5Siftwarden Boots";lore.add("§7Part of the Siftwarden set.");}
            default -> {return null;}
        }
        ItemStack item=new ItemStack(mat); ItemMeta meta=item.getItemMeta(); meta.setDisplayName(name); meta.setLore(lore); meta.getPersistentDataContainer().set(itemKey,PersistentDataType.STRING,id.toLowerCase(Locale.ROOT));
        if(id.toLowerCase(Locale.ROOT).startsWith("siftwarden_")){meta.addEnchant(Enchantment.PROTECTION,3,true);meta.addEnchant(Enchantment.UNBREAKING,3,true);}
        if(id.equalsIgnoreCase("riftblade")){meta.addEnchant(Enchantment.SHARPNESS,5,true);meta.addEnchant(Enchantment.UNBREAKING,3,true);}
        if(id.equalsIgnoreCase("sift_pickaxe")||id.equalsIgnoreCase("pickaxe")){meta.addEnchant(Enchantment.EFFICIENCY,5,true);meta.addEnchant(Enchantment.UNBREAKING,3,true);}
        item.setItemMeta(meta); return item;
    }
    private String customId(ItemStack item){ if(item==null||!item.hasItemMeta())return null; return item.getItemMeta().getPersistentDataContainer().get(itemKey,PersistentDataType.STRING); }
    private boolean hasItem(Player p,String id,int amount){int n=0;for(ItemStack it:p.getInventory().getContents())if(id.equals(customId(it)))n+=it.getAmount();return n>=amount;}
    private void consumeCustom(Player p,String id,int amount){ for(int i=0;i<p.getInventory().getSize()&&amount>0;i++){ItemStack it=p.getInventory().getItem(i);if(id.equals(customId(it))){int take=Math.min(amount,it.getAmount());it.setAmount(it.getAmount()-take);amount-=take;if(it.getAmount()<=0)p.getInventory().setItem(i,null);}} }
    private void registerRecipes(){
        addRecipe("sift_igniter", makeItem("sift_igniter"), new String[]{"EAE","ACA"," E "}, Map.of('E',Material.ECHO_SHARD,'A',Material.AMETHYST_SHARD,'C',Material.CRYING_OBSIDIAN));
        addRecipe("riftblade",makeItem("riftblade"),new String[]{" C "," C "," S "},Map.of('C',Material.AMETHYST_SHARD,'S',Material.NETHERITE_SWORD));
        addRecipe("sift_pickaxe",makeItem("sift_pickaxe"),new String[]{"CCC"," S "," S "},Map.of('C',Material.AMETHYST_SHARD,'S',Material.STICK));
        addRecipe("echo_lantern",makeItem("echo_lantern"),new String[]{" E ","ELE"," E "},Map.of('E',Material.ECHO_SHARD,'L',Material.LANTERN));
        addRecipe("sift_key",makeItem("sift_key"),new String[]{" AC"," S ","   "},Map.of('A',Material.AMETHYST_SHARD,'C',Material.COPPER_INGOT,'S',Material.STICK));
        if(getConfig().getBoolean("recipes.siftwarden",true)){
            addRecipe("siftwarden_helmet",makeItem("siftwarden_helmet"),new String[]{"CCC","C C","   "},Map.of('C',Material.AMETHYST_SHARD));
            addRecipe("siftwarden_chestplate",makeItem("siftwarden_chestplate"),new String[]{"C C","CCC","CCC"},Map.of('C',Material.AMETHYST_SHARD));
            addRecipe("siftwarden_leggings",makeItem("siftwarden_leggings"),new String[]{"CCC","C C","C C"},Map.of('C',Material.AMETHYST_SHARD));
            addRecipe("siftwarden_boots",makeItem("siftwarden_boots"),new String[]{"   ","C C","C C"},Map.of('C',Material.AMETHYST_SHARD));
        }
    }
    private void addRecipe(String key,ItemStack result,String[] shape,Map<Character,Material> ingredients){if(result==null||!getConfig().getBoolean("recipes."+key.replace("_", "-"),true))return; NamespacedKey k=new NamespacedKey(this,key); Bukkit.removeRecipe(k); ShapedRecipe recipe=new ShapedRecipe(k,result);recipe.shape(shape);ingredients.forEach(recipe::setIngredient);try{Bukkit.addRecipe(recipe);}catch(IllegalStateException ignored){}}

    @EventHandler public void onInteract(PlayerInteractEvent e){
        if(e.getHand()!=EquipmentSlot.HAND)return; Player p=e.getPlayer(); ItemStack held=e.getItem(); String id=customId(held);
        if(e.getAction()==Action.RIGHT_CLICK_BLOCK && e.getClickedBlock()!=null && e.getClickedBlock().getType()==Material.SCULK_CATALYST && isPortalCatalyst(e.getClickedBlock().getLocation())){
            e.setCancelled(true); if(!"sift_igniter".equals(id)){p.sendMessage(prefix()+ChatColor.GRAY+"The catalyst rejects the offering.");return;} activatePortal(p,e.getClickedBlock().getLocation());return;
        }
        if(e.getAction().isRightClick() && id!=null && (id.equals("riftblade")||id.equals("sift_pickaxe"))){
            long now=System.currentTimeMillis(), cd=abilityCooldown.getOrDefault(p.getUniqueId(),0L); if(now<cd)return;
            if(id.equals("sift_pickaxe")){p.addPotionEffect(new PotionEffect(PotionEffectType.HASTE,getConfig().getInt("items.sift-pickaxe.haste-seconds",4)*20,1));abilityCooldown.put(p.getUniqueId(),now+getConfig().getInt("items.sift-pickaxe.cooldown-seconds",10)*1000L);}
            else {for(Entity en:p.getNearbyEntities(4,3,4))if(en instanceof org.bukkit.entity.LivingEntity le && en!=p){le.damage(getConfig().getDouble("items.riftblade.damage-bonus",4),p);Vector v=le.getLocation().toVector().subtract(p.getLocation().toVector()).normalize().multiply(.8).setY(.25);le.setVelocity(v);}p.getWorld().spawnParticle(Particle.REVERSE_PORTAL,p.getLocation().add(0,1,0),45,.8,.6,.8,.03);p.getWorld().playSound(p.getLocation(),Sound.ENTITY_ENDERMAN_TELEPORT,.8f,1.4f);abilityCooldown.put(p.getUniqueId(),now+getConfig().getInt("items.riftblade.cooldown-seconds",8)*1000L);}
        }
    }
    private boolean isPortalCatalyst(Location l){String key=portalKey(l);return getConfig().getStringList("portals").contains(key);}
    private String portalKey(Location l){return l.getWorld().getName()+":"+l.getBlockX()+":"+l.getBlockY()+":"+l.getBlockZ();}
    private void activatePortal(Player p,Location catalyst){
        long now=System.currentTimeMillis();if(now<portalCooldown.getOrDefault(p.getUniqueId(),0L)){p.sendMessage(prefix()+ChatColor.RED+"The rift is still cooling down.");return;}
        int echo=getConfig().getInt("portal.consume-echo-shards",1), amethyst=getConfig().getInt("portal.consume-amethyst-shards",2);
        if(getConfig().getBoolean("portal.require-ritual-items",true)&&(!hasVanilla(p,Material.ECHO_SHARD,echo)||!hasVanilla(p,Material.AMETHYST_SHARD,amethyst))){msg(p,"ritual-failed");return;}
        if(getConfig().getBoolean("portal.require-ritual-items",true)){consumeVanilla(p,Material.ECHO_SHARD,echo);consumeVanilla(p,Material.AMETHYST_SHARD,amethyst);}
        portalCooldown.put(p.getUniqueId(),now+getConfig().getInt("portal.cooldown-seconds",8)*1000L); p.getWorld().playSound(catalyst,Sound.BLOCK_SCULK_SHRIEKER_SHRIEK,1f,.65f);
        int ticks=Math.max(1,getConfig().getInt("portal.animation-ticks",50)); new BukkitRunnable(){int t=0;public void run(){if(!p.isOnline()||!catalyst.getChunk().isLoaded()){cancel();return;}p.getWorld().spawnParticle(Particle.SCULK_SOUL,catalyst.clone().add(.5,1,.5),12,1,1,1,.03);p.getWorld().spawnParticle(Particle.PORTAL,catalyst.clone().add(.5,1,.5),20,.6,.8,.6,.1);if(t%10==0)p.getWorld().playSound(catalyst,Sound.BLOCK_BEACON_AMBIENT,.6f,1.1f+t*.01f);if(t++>=ticks){cancel();enter(p);}}}.runTaskTimer(this,0,1);
    }
    private boolean hasVanilla(Player p,Material m,int amount){return p.getInventory().all(m).values().stream().mapToInt(ItemStack::getAmount).sum()>=amount;}
    private void consumeVanilla(Player p,Material m,int amount){for(int i=0;i<p.getInventory().getSize()&&amount>0;i++){ItemStack it=p.getInventory().getItem(i);if(it!=null&&it.getType()==m){int n=Math.min(amount,it.getAmount());it.setAmount(it.getAmount()-n);amount-=n;if(it.getAmount()==0)p.getInventory().setItem(i,null);}}}
    @EventHandler public void onDamage(EntityDamageEvent e){if(!(e.getEntity() instanceof Player p))return;if(e.getCause()==EntityDamageEvent.DamageCause.FALL && fullSet(p))e.setDamage(e.getDamage()*.45);}
    @EventHandler public void onMove(PlayerMoveEvent e){if(e.getTo()==null||e.getFrom().getBlockY()==e.getTo().getBlockY())return;Player p=e.getPlayer();if(fullSet(p)){p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION,getConfig().getInt("armor.full-set-night-vision-seconds",12)*20,0,true,false));if(p.getWorld().equals(siftWorld))p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE,getConfig().getInt("armor.full-set-resistance-seconds",4)*20,getConfig().getInt("armor.full-set-resistance-amplifier",0),true,false));}}
    private boolean fullSet(Player p){return "siftwarden_helmet".equals(customId(p.getInventory().getHelmet()))&&"siftwarden_chestplate".equals(customId(p.getInventory().getChestplate()))&&"siftwarden_leggings".equals(customId(p.getInventory().getLeggings()))&&"siftwarden_boots".equals(customId(p.getInventory().getBoots()));}
    @EventHandler public void onJoin(PlayerJoinEvent e){if(siftWorld==null&&getConfig().getBoolean("world.auto-create",true))createSiftWorld();}
    @EventHandler public void onQuit(PlayerQuitEvent e){portalCooldown.remove(e.getPlayer().getUniqueId());abilityCooldown.remove(e.getPlayer().getUniqueId());saveReturnLocations();}

    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){
        if(args.length==0){sender.sendMessage(prefix()+"§d/sift enter §7| §dreturn §7| §dancientportal [remove|locate] §7| §dinfo");if(sender.hasPermission("ngssift.admin"))sender.sendMessage(prefix()+"§dsetspawn, givekey, givearmor, giveitem, reload");return true;}
        String sub=args[0].toLowerCase(Locale.ROOT);
        if(sub.equals("enter")||sub.equals("return")){if(!(sender instanceof Player p)){sender.sendMessage("Players only.");return true;}if(sub.equals("enter"))enter(p);else returnPlayer(p);return true;}
        if(sub.equals("info")){sender.sendMessage(prefix()+"§dWorld: §f"+(siftWorld==null?"not loaded":siftWorld.getName())+" §d| Portals: §f"+getConfig().getStringList("portals").size());return true;}
        if(!sender.hasPermission("ngssift.admin")){sender.sendMessage(prefix()+ChatColor.RED+"Admin permission required.");return true;}
        switch(sub){
            case "reload" -> {reloadConfig();sender.sendMessage(prefix()+ChatColor.GREEN+"Configuration reloaded. Restart to apply world-generator changes.");}
            case "setspawn" -> {if(!(sender instanceof Player p)){sender.sendMessage("Players only.");break;}if(!p.getWorld().getName().equals(getConfig().getString("world.name","sift"))){sender.sendMessage(prefix()+"Stand inside The Sift first.");break;}getConfig().set("world.spawn.x",p.getLocation().getBlockX());getConfig().set("world.spawn.y",p.getLocation().getBlockY());getConfig().set("world.spawn.z",p.getLocation().getBlockZ());siftWorld.setSpawnLocation(p.getLocation());saveConfig();sender.sendMessage(prefix()+"Sift spawn updated.");}
            case "givekey" -> {if(!(sender instanceof Player p)){sender.sendMessage("Players only.");break;}give(p,makeItem("sift_igniter"));}
            case "givearmor" -> {if(!(sender instanceof Player p)){sender.sendMessage("Players only.");break;}for(String id:List.of("siftwarden_helmet","siftwarden_chestplate","siftwarden_leggings","siftwarden_boots"))give(p,makeItem(id));}
            case "giveitem" -> {if(args.length<3){sender.sendMessage("Usage: /sift giveitem <player> <item>");break;}Player target=Bukkit.getPlayerExact(args[1]);ItemStack item=makeItem(args[2]);if(target==null||item==null){sender.sendMessage("Unknown player or item. Items: sift_igniter, riftblade, sift_pickaxe, echo_lantern, sift_crystal, ancient_core, sift_key, helmet, chestplate, leggings, boots");break;}give(target,item);sender.sendMessage("Given "+args[2]+" to "+target.getName());}
            case "ancientportal" -> {if(args.length>1&&args[1].equalsIgnoreCase("locate")){locatePortal(sender);break;}if(args.length>1&&args[1].equalsIgnoreCase("remove")){removePortal(sender);break;}if(!(sender instanceof Player p)){sender.sendMessage("Players only; run this in the world where you want to search.");break;}buildAncientPortal(p);}
            default -> sender.sendMessage("Unknown subcommand. Use /sift.");
        }return true;
    }
    private void give(Player p,ItemStack item){if(item==null)return;Map<Integer,ItemStack> left=p.getInventory().addItem(item);left.values().forEach(it->p.getWorld().dropItemNaturally(p.getLocation(),it));}
    private void buildAncientPortal(Player p){World w=p.getWorld();Location city=w.locateNearestStructure(p.getLocation(),Structure.ANCIENT_CITY,getConfig().getInt("portal.locate-radius-chunks",100),false);if(city==null){p.sendMessage(prefix()+"§cNo Ancient City found within search range. Try closer to a known city.");return;}
        Location center=null;for(int r=0;r<=10&&center==null;r++)for(int dx=-r;dx<=r&&center==null;dx++)for(int dz=-r;dz<=r&&center==null;dz++){Location base=city.clone().add(dx,0,dz);int y=w.getHighestBlockYAt(base);Location c=new Location(w,base.getBlockX(),y+1,base.getBlockZ());if(c.getBlock().isPassable()&&c.clone().add(0,1,0).getBlock().isPassable()&&c.clone().subtract(0,1,0).getBlock().getType().isSolid())center=c;}
        if(center==null){p.sendMessage(prefix()+"§cCould not find a safe open spot beside that Ancient City.");return;}
        // Only place into air/replaceable blocks; preserve all non-replaceable city blocks.
        List<Location> made=new ArrayList<>();int x=center.getBlockX(),y=center.getBlockY(),z=center.getBlockZ();
        for(int dx=-2;dx<=2;dx++)for(int dy=0;dy<=3;dy++)for(int dz=-1;dz<=1;dz++){
            boolean frame=(Math.abs(dx)==2||dy==0||dy==3||Math.abs(dz)==1); if(!frame)continue;Location at=new Location(w,x+dx,y+dy,z+dz);Material mat=(dy==1&&dx==0&&dz==0)?Material.SCULK_CATALYST:((Math.abs(dx)==2||dy==0||dy==3)?Material.DEEPSLATE_BRICKS:Material.CRYING_OBSIDIAN);
            if(at.getBlock().getType().isAir()||at.getBlock().isPassable()){at.getBlock().setType(mat,false);made.add(at);}
        }
        Location catalyst=new Location(w,x,y+1,z);if(catalyst.getBlock().getType()!=Material.SCULK_CATALYST){if(catalyst.getBlock().isPassable()){catalyst.getBlock().setType(Material.SCULK_CATALYST,false);made.add(catalyst);}else{p.sendMessage(prefix()+"§cPortal activation space is blocked; no catalyst placed.");return;}}
        List<String> portals=getConfig().getStringList("portals");String key=portalKey(catalyst);if(!portals.contains(key))portals.add(key);getConfig().set("portals",portals);List<String> owned=getConfig().getStringList("portal-blocks."+key);for(Location l:made)owned.add(l.getBlockX()+","+l.getBlockY()+","+l.getBlockZ());getConfig().set("portal-blocks."+key,owned);saveConfig();
        w.spawnParticle(Particle.SCULK_SOUL,catalyst.clone().add(.5,1,.5),40,1,1,1,.04);w.playSound(catalyst,Sound.BLOCK_SCULK_CATALYST_BLOOM,1,0.8f);p.sendMessage(prefix()+"§aPortal built near Ancient City at §f"+x+", "+(y+1)+", "+z+"§a. Activate with Sift Igniter + ritual ingredients.");
    }
    private void locatePortal(CommandSender s){List<String> list=getConfig().getStringList("portals");if(list.isEmpty()){s.sendMessage(prefix()+"No saved Sift portals.");return;}Location from=s instanceof Player p?p.getLocation():Bukkit.getWorlds().get(0).getSpawnLocation();String best=null;double dist=Double.MAX_VALUE;for(String k:list){String[] a=k.split(":");if(a.length!=4)continue;World w=Bukkit.getWorld(a[0]);if(w==null)continue;try{Location l=new Location(w,Integer.parseInt(a[1]),Integer.parseInt(a[2]),Integer.parseInt(a[3]));double d=w.equals(from.getWorld())?l.distanceSquared(from):Double.MAX_VALUE;if(d<dist){dist=d;best=k;}}catch(Exception ignored){}}s.sendMessage(prefix()+(best==null?"Saved portal exists in an unloaded world.":"Nearest portal: "+best.replace(':',' ')));}
    private void removePortal(CommandSender s){if(!(s instanceof Player p)){s.sendMessage("Players only; stand near the portal.");return;}List<String> portals=getConfig().getStringList("portals");String chosen=null;double best=Double.MAX_VALUE;for(String k:portals){String[] a=k.split(":");if(a.length!=4||!a[0].equals(p.getWorld().getName()))continue;try{Location l=new Location(p.getWorld(),Integer.parseInt(a[1]),Integer.parseInt(a[2]),Integer.parseInt(a[3]));double d=l.distanceSquared(p.getLocation());if(d<best){best=d;chosen=k;}}catch(Exception ignored){}}if(chosen==null){p.sendMessage(prefix()+"No portal in this world.");return;}for(String coords:getConfig().getStringList("portal-blocks."+chosen)){try{String[] a=coords.split(",");Block b=p.getWorld().getBlockAt(Integer.parseInt(a[0]),Integer.parseInt(a[1]),Integer.parseInt(a[2]));Material t=b.getType();if(t==Material.DEEPSLATE_BRICKS||t==Material.CRYING_OBSIDIAN||t==Material.SCULK_CATALYST)b.setType(Material.AIR,false);}catch(Exception ignored){}}String[] a=chosen.split(":");try{p.getWorld().getBlockAt(Integer.parseInt(a[1]),Integer.parseInt(a[2]),Integer.parseInt(a[3])).setType(Material.AIR,false);}catch(Exception ignored){}portals.remove(chosen);getConfig().set("portals",portals);getConfig().set("portal-blocks."+chosen,null);saveConfig();p.sendMessage(prefix()+"Plugin-recorded portal blocks removed where still matching.");}
    private String prefix(){return ChatColor.translateAlternateColorCodes('&',getConfig().getString("messages.prefix","&8[&5NGS SIFT&8] &r"));}
    private void msg(Player p,String key){p.sendMessage(prefix()+ChatColor.translateAlternateColorCodes('&',getConfig().getString("messages."+key,key)));}
    @Override public List<String> onTabComplete(CommandSender s,Command c,String a,String[] args){if(args.length==1)return filter(List.of("enter","return","ancientportal","givekey","givearmor","giveitem","reload","setspawn","info"),args[0]);if(args.length==2&&args[0].equalsIgnoreCase("ancientportal"))return filter(List.of("locate","remove"),args[1]);if(args.length==2&&args[0].equalsIgnoreCase("giveitem"))return null;if(args.length==3&&args[0].equalsIgnoreCase("giveitem"))return filter(List.of("sift_igniter","riftblade","sift_pickaxe","echo_lantern","sift_crystal","ancient_core","sift_key","helmet","chestplate","leggings","boots"),args[2]);return Collections.emptyList();}
    private List<String> filter(List<String> values,String token){return values.stream().filter(x->x.toLowerCase(Locale.ROOT).startsWith(token.toLowerCase(Locale.ROOT))).toList();}
}
