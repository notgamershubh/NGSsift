# NGSSift — NGS EMPIRE

A Paper plugin project targeting **Minecraft Java 1.21.11 / Java 21**. It creates a separate `sift` world with a deterministic custom terrain generator, procedural ruins/crystal seams, an Ancient City portal ritual, persistent return locations, custom PDC-tagged items, armor set effects, recipes, and admin commands.

## Build

Requirements: JDK 21 and Maven 3.9+; internet access is required on the first build to resolve Paper API and Maven dependencies.

```bash
mvn -U clean package
```

Expected output: `target/NGSSift-1.0.0.jar`.

> Build status in this delivery: **not compiled here**. The execution environment had Java 21 but no Maven executable and DNS/network access to Paper's repository was unavailable. Do not treat the JAR as validated until you build it and check the server log. The ZIP contains the complete source project, not a precompiled JAR.

## Install

1. Back up the server and stop Paper.
2. Build the project with the command above.
3. Copy `target/NGSSift-1.0.0.jar` into the server's `plugins/` folder.
4. Start Paper 1.21.11 once. Review startup logs and allow the plugin to create `plugins/NGSSift/config.yml` and the separate `sift` world.
5. Stop the server before editing config, then restart. Do not delete or rename your existing survival world.
6. Grant admin permissions only to trusted operators. Admin commands require `ngssift.admin`.

## Commands

- `/sift` — help
- `/sift enter` — save current location and enter The Sift
- `/sift return` — return to saved location, or main world spawn if no valid saved location exists
- `/sift ancientportal` — find the nearest Ancient City in the current world and place a portal in a nearby open area
- `/sift ancientportal locate` — show nearest saved portal coordinates
- `/sift ancientportal remove` — remove recorded portal blocks near the player, where their block types still match
- `/sift givekey` — give a Sift Igniter
- `/sift givearmor` — give Siftwarden armor pieces
- `/sift giveitem <player> <item>` — give a supported custom item
- `/sift setspawn` — set The Sift spawn at your current location
- `/sift reload` — reload configuration (generator changes need a restart/new chunks)
- `/sift info` — show dimension and portal count

Supported item IDs: `sift_igniter`, `riftblade`, `sift_pickaxe`, `echo_lantern`, `sift_crystal`, `ancient_core`, `sift_key`, `helmet`, `chestplate`, `leggings`, `boots`.

## Portal ritual

Use `/sift ancientportal` while in the world containing an Ancient City. The portal catalyst is a Sculk Catalyst. Right-click it while holding a genuine plugin-created Sift Igniter. By default, the ritual consumes 1 vanilla Echo Shard and 2 vanilla Amethyst Shards. These requirements and the animation/cooldown are configurable. Flint and steel is not used to activate the portal.

## Generation and API limits

- `sift` uses a custom `ChunkGenerator` and an existing-world custom biome provider. Terrain is distinct from the Overworld and includes ridges/plateaus, cave pockets, fissures, crystal seams, and deterministic small ruins.
- The generator uses existing vanilla blocks and biome IDs. It does **not** register a new vanilla biome or a native dimension type; those require datapack/registry or server internals outside the stable plugin API.
- The portal builder is deliberately conservative and only places blocks in air/passable positions. On dense Ancient City terrain it may produce an incomplete frame rather than overwrite the city. Use a cleared adjacent space if necessary.
- Procedural generator ruins are decorative block formations; configurable weighted loot-table parsing and automatically populated shrine chests are not implemented in this version, despite the starter config's loot section. The Sift Key is currently a tagged custom item and is not wired to a chest-unlocking system.
- The resource-pack folder is a template only. Vanilla materials do not gain unique textures without a correctly built and distributed resource pack; this plugin does not claim otherwise.
- World-generation settings apply to newly generated chunks. Existing chunks are not regenerated.

## Test checklist on a staging server

1. Use a disposable Paper 1.21.11 server and Java 21.
2. Build with `mvn -U clean package`, place the JAR in `plugins/`, and start the server.
3. Confirm there are no plugin load errors; run `/plugins` and `/sift info`.
4. Run `/sift enter`; explore multiple newly generated chunks; confirm the normal world was not altered.
5. Run `/sift return` and restart the server to check persistence.
6. In an Ancient City world, run `/sift ancientportal`; try activating it with `/sift givekey` plus Echo Shards and Amethyst Shards.
7. Test all `/sift giveitem` item IDs, recipes, ability cooldowns, armor set effects, and `/sift ancientportal remove` on staging before deploying to the live server.

## Troubleshooting

- **Unsupported Java version:** use Java 21 for the server and build.
- **Paper API cannot resolve:** check internet/DNS, repository access, and run `mvn -U clean package` again.
- **Generator looks unchanged:** travel into newly generated chunks; existing chunks are never rewritten.
- **Ancient City not found:** execute the command in the intended world and closer to a known Ancient City; searches are radius-bounded and do not scan the whole world.
- **Portal frame incomplete:** the plugin refuses to overwrite non-passable blocks. Clear a small adjacent area and create the portal again.
- **Return goes to main spawn:** the stored world may not be loaded/available or no valid return location was saved.
- **Recipe absent:** inspect `recipes.enabled` and the corresponding recipe toggle, then restart the server.

## Permissions

- `ngssift.use` — default true
- `ngssift.admin` — default OP
- `ngssift.items` — declared for item-related access policy; current command access for giving items is guarded by `ngssift.admin`.

## Important delivery note

This source package has **not been compiled or tested against a running Paper 1.21.11 server in this environment**. Run the staging checklist above before installation on the live NGS EMPIRE server. The config includes some future-facing loot/structure options for clarity; the limitations above identify which systems are not yet wired up.
