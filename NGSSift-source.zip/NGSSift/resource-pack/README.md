# Optional resource-pack template

This folder is a placeholder for future custom textures/models. No custom texture is included and the plugin currently uses vanilla materials. To use custom visuals, create valid texture PNGs and model JSONs for the target client version, set the matching custom model component/data in the plugin, and distribute the pack via server resource-pack settings. Update `pack.mcmeta` to the resource-pack format for the exact Minecraft client version you target.
